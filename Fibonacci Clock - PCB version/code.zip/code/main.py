from machine import Pin, RTC
import utime
import json
import network
import urequests
from neopixel import Neopixel

# ==================================================
# LONG BOOT DELAY (CRITICAL FOR EXTERNAL POWER)
# ==================================================
utime.sleep(2)

# ==================================================
# LED STRIP SETUP
# ==================================================
NUM_LEDS = 50
PIN_NUM = 0
np = Neopixel(NUM_LEDS, 0, PIN_NUM, "GRB")

# IMPORTANT: lower brightness to avoid brownout
np.brightness(150)

# Fibonacci block sizes
BLOCKS = [1, 1, 6, 12, 30]  # Total = 50 LEDs

BLOCK_START = [0]
for i in range(1, 5):
    BLOCK_START.append(BLOCK_START[i - 1] + BLOCKS[i - 1])

# Colors
RED    = (255, 0, 0)
BLUE   = (0, 0, 255)
GREEN  = (0, 255, 0)
WHITE  = (255, 255, 255)
PURPLE = (50, 0, 50)    # Boot
YELLOW = (50, 50, 0)    # WiFi fail
CYAN   = (0, 50, 50)    # WiFi OK
LIME   = (0, 50, 0)     # Time synced

# ==================================================
# BOOT INDICATOR
# ==================================================
for i in range(NUM_LEDS):
    np.set_pixel(i, PURPLE)
np.show()

# ==================================================
# LOAD CONFIG
# ==================================================
with open("config.json") as f:
    config = json.load(f)

ssid = config["ssid"]
password = config["ssid_password"]
date_time_api = config["date_time_api"]
timezone = config["time_zone"]

# ==================================================
# WIFI (HARD RESET + TIMEOUT)
# ==================================================
def connect_wifi(timeout=10):
    wlan = network.WLAN(network.STA_IF)

    # HARD RESET WIFI CHIP
    wlan.active(False)
    utime.sleep(1)

    wlan.active(True)
    utime.sleep(2)

    wlan.connect(ssid, password)

    start = utime.time()
    while not wlan.isconnected():
        if utime.time() - start > timeout:
            return False
        utime.sleep(1)

    return True

# ==================================================
# TIME SYNC (SAFE)
# ==================================================
def sync_time(rtc):
    try:
        url = (
            "http://api.ipgeolocation.io/timezone"
            "?apiKey={}&tz={}".format(date_time_api, timezone)
        )
        r = urequests.get(url)
        d = r.json()
        r.close()

        date, t = d["date_time"].split(" ")
        y, m, day = map(int, date.split("-"))
        h, mi, s = map(int, t.split(":"))

        # weekday not needed → set to 0
        rtc.datetime((y, m, day, 0, h, mi, s, 0))
        return True
    except Exception as e:
        print("Time sync error:", e)
        return False

# ==================================================
# FIBONACCI TIME
# ==================================================
def fib_time(hours, minutes):
    vals = [1, 1, 2, 3, 5]
    state = [0, 0, 0, 0, 0]

    h = hours % 12
    idx = 4
    for v in reversed(vals):
        if h >= v:
            state[idx] += 1
            h -= v
        idx -= 1

    m = minutes // 5
    idx = 4
    for v in reversed(vals):
        if m >= v:
            state[idx] += 2
            m -= v
        idx -= 1

    return state

# ==================================================
# LED BLOCK FILL
# ==================================================
def fill_block(block_index, color):
    start = BLOCK_START[block_index]
    length = BLOCKS[block_index]
    for i in range(length):
        np.set_pixel(start + i, color)

# ==================================================
# RTC + STARTUP SEQUENCE
# ==================================================
rtc = RTC()

if connect_wifi():
    # WiFi OK indicator
    for i in range(NUM_LEDS):
        np.set_pixel(i, CYAN)
    np.show()
    utime.sleep(1)

    if sync_time(rtc):
        # Time OK indicator
        for i in range(NUM_LEDS):
            np.set_pixel(i, LIME)
        np.show()
        utime.sleep(1)
else:
    # WiFi failed indicator
    for i in range(NUM_LEDS):
        np.set_pixel(i, YELLOW)
    np.show()
    utime.sleep(2)

# ==================================================
# MAIN LOOP
# ==================================================
while True:
    Y, M, D, W, H, Min, S, SS = rtc.datetime()

    state = fib_time(H, Min)
    print("Time:", H, Min, "| State:", state)

    for i in range(5):
        if state[i] == 0:
            fill_block(i, WHITE)
        elif state[i] == 1:
            fill_block(i, RED)
        elif state[i] == 2:
            fill_block(i, BLUE)
        elif state[i] == 3:
            fill_block(i, GREEN)

    np.show()
    utime.sleep(1)
