###############################################
# 64×64 WAVESHARE RGB PANEL ANIMATION PLAYER  #
# NO BUTTON VERSION                           #
###############################################

import time
import os
import board
import displayio
import framebufferio
import rgbmatrix

# ------------------------------------------------
# REQUIRED → clear any previous display buses
# ------------------------------------------------
displayio.release_displays()

# ------------------------------------------------
# WAVESHARE RGBMatrix SETUP (verified working)
# ------------------------------------------------
bit_depth_value = 3
unit_width = 64
unit_height = 64

matrix = rgbmatrix.RGBMatrix(
    width = unit_width,
    height = unit_height,
    bit_depth = bit_depth_value,
    rgb_pins = [board.GP2, board.GP3, board.GP4, board.GP5, board.GP8, board.GP9],
    addr_pins = [board.GP10, board.GP16, board.GP18, board.GP20, board.GP22],
    clock_pin = board.GP11,
    latch_pin = board.GP12,
    output_enable_pin = board.GP13,
    tile = 1,
    serpentine = True,
    doublebuffer = True,
)

DISPLAY = framebufferio.FramebufferDisplay(matrix, auto_refresh=True)

# ------------------------------------------------
# Animation settings
# ------------------------------------------------
SPRITESHEET_FOLDER = "/bmps"
DEFAULT_FRAME_DURATION = 0.1    # seconds
AUTO_ADVANCE_LOOPS = 4          # how many loops per animation before switching

FRAME_DURATION_OVERRIDES = {
    "1.bmp": 0.1,
    "2.bmp": 0.1,
    "3.bmp": 0.1,
}

# ------------------------------------------------
# Load animation files
# ------------------------------------------------
file_list = sorted(
    f for f in os.listdir(SPRITESHEET_FOLDER)
    if f.endswith(".bmp") and not f.startswith(".")
)

if not file_list:
    raise RuntimeError("No BMP files found in /bmps")

current_image = None
current_frame = 0
current_loop = 0
frame_count = 0
frame_duration = DEFAULT_FRAME_DURATION

# Display group for animation
sprite_group = displayio.Group()


# ------------------------------------------------
# Load spritesheet and prepare animation frames
# ------------------------------------------------
def load_image():
    global current_frame, current_loop, frame_count, frame_duration

    while len(sprite_group):
        sprite_group.pop()

    filename = SPRITESHEET_FOLDER + "/" + file_list[current_image]
    bitmap = displayio.OnDiskBitmap(open(filename, "rb"))

    FRAME_HEIGHT = 64  # required per-frame height for 64×64

    sprite = displayio.TileGrid(
        bitmap,
        pixel_shader=getattr(bitmap, "pixel_shader", displayio.ColorConverter()),
        width=1,
        height=1,
        tile_width=bitmap.width,
        tile_height=FRAME_HEIGHT,
    )

    sprite_group.append(sprite)
    DISPLAY.show(sprite_group)

    current_frame = 0
    current_loop = 0
    frame_count = bitmap.height // FRAME_HEIGHT

    frame_duration = FRAME_DURATION_OVERRIDES.get(
        file_list[current_image], DEFAULT_FRAME_DURATION
    )


# ------------------------------------------------
# Switch to next animation file
# ------------------------------------------------
def advance_image():
    global current_image

    if current_image is None:
        current_image = 0
    else:
        current_image += 1

    if current_image >= len(file_list):
        current_image = 0

    load_image()


# ------------------------------------------------
# Advance one animation frame
# ------------------------------------------------
def advance_frame():
    global current_frame, current_loop

    current_frame += 1

    if current_frame >= frame_count:
        current_frame = 0
        current_loop += 1

    sprite_group[0][0] = current_frame


# ------------------------------------------------
# Start animation
# ------------------------------------------------
advance_image()

# ------------------------------------------------
# MAIN LOOP (no buttons)
# ------------------------------------------------
while True:

    # Auto-switch to next file after loops
    if current_loop >= AUTO_ADVANCE_LOOPS:
        advance_image()

    advance_frame()
    time.sleep(frame_duration)
