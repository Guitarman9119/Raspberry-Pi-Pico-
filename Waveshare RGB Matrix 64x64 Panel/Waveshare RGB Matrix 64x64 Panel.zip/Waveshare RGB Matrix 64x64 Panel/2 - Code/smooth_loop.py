###############################################
# 64×64 WAVESHARE RGB PANEL ANIMATION PLAYER  #
# SMOOTH LOOP VERSION (ONE BMP ONLY)          #
###############################################

import time
import os
import board
import displayio
import framebufferio
import rgbmatrix

# ------------------------------------------------
# REQUIRED → clear any previous display buses
# ------------------------------------------------
displayio.release_displays()

# ------------------------------------------------
# WAVESHARE RGBMatrix SETUP (verified working)
# ------------------------------------------------
matrix = rgbmatrix.RGBMatrix(
    width = 64,
    height = 64,
    bit_depth = 3,
    rgb_pins = [board.GP2, board.GP3, board.GP4, board.GP5, board.GP8, board.GP9],
    addr_pins = [board.GP10, board.GP16, board.GP18, board.GP20, board.GP22],
    clock_pin = board.GP11,
    latch_pin = board.GP12,
    output_enable_pin = board.GP13,
    tile = 1,
    serpentine = True,
    doublebuffer = True,
)

DISPLAY = framebufferio.FramebufferDisplay(matrix, auto_refresh=True)

# ------------------------------------------------
# Only ONE animation file
# ------------------------------------------------
SPRITESHEET_FOLDER = "/bmps"

file_list = [
    f for f in os.listdir(SPRITESHEET_FOLDER)
    if f.endswith(".bmp") and not f.startswith(".")
]

if len(file_list) != 1:
    raise RuntimeError("Put EXACTLY ONE BMP inside /bmps for smooth looping.")

filename = SPRITESHEET_FOLDER + "/" + file_list[0]

# Load the spritesheet ONCE
bitmap = displayio.OnDiskBitmap(open(filename, "rb"))

FRAME_HEIGHT = 64
frame_count = bitmap.height // FRAME_HEIGHT
frame_duration = 0.1  # Adjust for animation speed

# ------------------------------------------------
# Display group and TileGrid
# ------------------------------------------------
sprite_group = displayio.Group()

sprite = displayio.TileGrid(
    bitmap,
    pixel_shader=getattr(bitmap, "pixel_shader", displayio.ColorConverter()),
    width=1,
    height=1,
    tile_width=bitmap.width,
    tile_height=FRAME_HEIGHT,
)

sprite_group.append(sprite)
DISPLAY.show(sprite_group)
current_frame = 0

while True:
    sprite[0] = current_frame      # show frame
    current_frame += 1

    if current_frame >= frame_count:
        current_frame = 0          # loop smoothly

    time.sleep(frame_duration)
