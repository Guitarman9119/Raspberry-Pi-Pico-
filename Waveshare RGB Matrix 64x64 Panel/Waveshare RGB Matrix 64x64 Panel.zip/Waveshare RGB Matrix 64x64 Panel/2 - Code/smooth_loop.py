###############################################
# 64×64 WAVESHARE RGB PANEL ANIMATION PLAYER  #
# LOOP A SELECTED BMP SMOOTHLY                #
###############################################

import time
import os
import board
import displayio
import framebufferio
import rgbmatrix

displayio.release_displays()

matrix = rgbmatrix.RGBMatrix(
    width = 64,
    height = 64,
    bit_depth = 1,
    rgb_pins = [board.GP2, board.GP3, board.GP4, board.GP5, board.GP8, board.GP9],
    addr_pins = [board.GP10, board.GP16, board.GP18, board.GP20, board.GP22],
    clock_pin = board.GP11,
    latch_pin = board.GP12,
    output_enable_pin = board.GP13,
    tile = 1,
    serpentine = True,
    doublebuffer = True,
)

DISPLAY = framebufferio.FramebufferDisplay(matrix, auto_refresh=True)

# ------------------------------------------------
# Select which BMP file to loop
# ------------------------------------------------
SPRITESHEET_FOLDER = "/bmps"
FILENAME = "2.bmp"     # ← change this to any BMP you want

filename = SPRITESHEET_FOLDER + "/" + FILENAME
bitmap = displayio.OnDiskBitmap(open(filename, "rb"))

FRAME_HEIGHT = 64
frame_count = bitmap.height // FRAME_HEIGHT
frame_duration = 0.1

# ------------------------------------------------
# Display group / TileGrid
# ------------------------------------------------
sprite_group = displayio.Group()

sprite = displayio.TileGrid(
    bitmap,
    pixel_shader=getattr(bitmap, "pixel_shader", displayio.ColorConverter()),
    width=1,
    height=1,
    tile_width=bitmap.width,
    tile_height=FRAME_HEIGHT,
)

sprite_group.append(sprite)
DISPLAY.show(sprite_group)

current_frame = 0

# ------------------------------------------------
# MAIN LOOP
# ------------------------------------------------
while True:
    sprite[0] = current_frame
    current_frame += 1

    if current_frame >= frame_count:
        current_frame = 0

    time.sleep(frame_duration)
