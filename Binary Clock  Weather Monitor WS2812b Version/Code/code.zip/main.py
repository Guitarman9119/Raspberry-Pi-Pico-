import utime
from machine import Pin, I2C, RTC
import json
import urequests
import network
from ssd1306 import SSD1306_I2C
from neopixel import Neopixel  


# ============================
# NeoPixel Setup (20 LEDs)
# ============================
NUM_LEDS = 20
PIN_NUM = 0
STATE_MACHINE = 0

np = Neopixel(NUM_LEDS, STATE_MACHINE, PIN_NUM, "GRB")
np.brightness(80)  # optional: 1-255


# Time colors (EDIT THESE ANYTIME)
# NOTE: Your tuple format is (R, G, B) — library handles GRB packing internally
COLOR_HOURS   = (255, 0, 0)     # Red
COLOR_MINUTES = (0, 0, 255)     # Blue
COLOR_SECONDS = (0, 180, 180)   # Cyan-ish


def all_off():
    np.clear()
    np.show()


# LED Groups: start index or custom list
groups = {
    "H_tens":  (0, 2),
    "H_ones":  (2, 4),
    "M_tens":  (6, 3),
    "M_ones":  (9, 4),
    "S_tens":  (13, 3),
    "S_ones":  (16, 4),  
}

# LSB first + supports custom lists
def set_group_value(group, length, value, color):
    if isinstance(group, list):
        for i in range(length):
            bit = (value >> i) & 1
            np.set_pixel(group[i], color if bit else (0, 0, 0))
    else:
        start = group
        for i in range(length):
            bit = (value >> i) & 1
            np.set_pixel(start + i, color if bit else (0, 0, 0))


def update_leds_ws2812():
    Y, M, D, W, H, Min, S, SS = rtc.datetime()
    h1, h2 = divmod(H, 10)
    m1, m2 = divmod(Min, 10)
    s1, s2 = divmod(S, 10)

    set_group_value(*groups["H_tens"], h1, COLOR_HOURS)
    set_group_value(*groups["H_ones"], h2, COLOR_HOURS)

    set_group_value(*groups["M_tens"], m1, COLOR_MINUTES)
    set_group_value(*groups["M_ones"], m2, COLOR_MINUTES)

    set_group_value(*groups["S_tens"], s1, COLOR_SECONDS)
    set_group_value(*groups["S_ones"], s2, COLOR_SECONDS)

    np.show()


# ============================
# WiFi + API + RTC + OLED
# ============================
with open('config.json') as f:
    config = json.load(f)

if config['ssid'] == 'Enter_Wifi_SSID':
    raise ValueError("config.json not updated")

weather_api_key = config['weather_api_key']
city = config['city']
country_code = config['country_code']
date_time_api = config['date_time_api']
timezone = config['time_zone']

# WiFi Init
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
print("Connecting to WiFi:", config['ssid'])
wlan.connect(config['ssid'], config['ssid_password'])
while not wlan.isconnected():
    utime.sleep(1)
print("Connected:", wlan.ifconfig())

rtc = RTC()

def sync_time_with_ip_geolocation_api(rtc):
    try:
        url = f'http://api.ipgeolocation.io/timezone?apiKey={date_time_api}&tz={timezone}'
        r = urequests.get(url)
        d = r.json()
        r.close()

        date, t = d["date_time"].split(" ")
        y, m, day = map(int, date.split("-"))
        h, mi, s = map(int, t.split(":"))
        wd = d.get("day_of_week", 0)

        rtc.datetime((y, m, day, wd, h, mi, s, 0))
        return True
    except:
        return False

def fetch_weather():
    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city},{country_code}&appid={weather_api_key}&units=metric"
        r = urequests.get(url)
        d = r.json()
        r.close()
        return {
            'location': f"{d['name']} - {d['sys']['country']}",
            'description': d['weather'][0]['main'],
            'temperature': d['main']['temp'],
            'pressure': d['main']['pressure'],
            'humidity': d['main']['humidity'],
            'wind_speed': d['wind']['speed'],
        }
    except:
        return None

# OLED Setup
i2c = I2C(0, scl=Pin(17), sda=Pin(16), freq=400000)
display = SSD1306_I2C(128, 64, i2c)

def show_status(msg, line=0):
    display.fill(0)
    display.text("NerdCave Clock", 0, 0)
    display.text(msg, 0, 20 + line*12)
    display.show()

# Buttons
btn_next = Pin(1, Pin.IN, Pin.PULL_DOWN)
btn_prev = Pin(2, Pin.IN, Pin.PULL_DOWN)
current_page = 0
total_pages = 3

def handle_buttons():
    global current_page
    if btn_next.value():
        current_page = (current_page + 1) % total_pages
        utime.sleep_ms(250)
    if btn_prev.value():
        current_page = (current_page - 1) % total_pages
        utime.sleep_ms(250)

# OLED Pages
def display_time_date():
    Y, M, D, W, H, Min, S, SS = rtc.datetime()
    display.fill(0)
    display.text("NerdCave Clock", 0, 0)
    display.text(f"{D:02}-{M:02}-{Y}", 0, 20)
    display.text(f"{H:02}:{Min:02}:{S:02}", 0, 35)
    display.show()

def display_weather_basic(w):
    display.fill(0)
    display.text("Weather:", 0, 0)
    display.text(w['location'], 0, 12)
    display.text(f"T:{w['temperature']}C", 0, 24)
    display.text(w['description'], 0, 36)
    display.text(f"H:{w['humidity']}%", 0, 48)
    display.show()

def display_weather_extended(w):
    display.fill(0)
    display.text("Weather Ext:", 0, 0)
    display.text(f"P:{w['pressure']}", 0, 16)
    display.text(f"W:{w['wind_speed']}m/s", 0, 32)
    display.text(f"T:{w['temperature']}C", 0, 48)
    display.show()

# Startup
show_status("WiFi OK")
w = fetch_weather()
show_status("Weather OK" if w else "Weather ERR")

show_status("Time OK" if sync_time_with_ip_geolocation_api(rtc) else "Time ERR", 1)

# Optional: clear LEDs on boot
all_off()

# Main Loop
last_weather_update = utime.time()
last_time_sync = utime.time()
last_tick = utime.ticks_ms()

while True:
    if utime.ticks_diff(utime.ticks_ms(), last_tick) >= 1000:
        last_tick = utime.ticks_ms()

        handle_buttons()
        update_leds_ws2812()

        if current_page == 0:
            display_time_date()
        elif current_page == 1 and w:
            display_weather_basic(w)
        elif current_page == 2 and w:
            display_weather_extended(w)

        if utime.time() - last_weather_update > 600:
            w = fetch_weather()
            last_weather_update = utime.time()

        if utime.time() - last_time_sync > 600:
            sync_time_with_ip_geolocation_api(rtc)
            last_time_sync = utime.time()