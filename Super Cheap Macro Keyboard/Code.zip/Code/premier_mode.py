import time
import board, busio, displayio, os, terminalio
import digitalio
import time
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control_code import ConsumerControlCode
from adafruit_display_text import label
import adafruit_displayio_ssd1306

def update_screen(splash, macro_name, display):
    # Update the macro label
    center_x = (118 - len(macro_name) * 6) // 2 + 5
    macro_label = label.Label(terminalio.FONT, text=macro_name, color=0xFFFF00, x=center_x, y=50)
    splash.append(macro_label)
    display.refresh()
    # Wait for 3 seconds
    time.sleep(1)
    # Remove the macro label after 3 seconds
    splash.remove(macro_label)
    display.refresh()


def handle_keypress(event, cc, write_text, keyboard, SW1, SW2, rotary_changed_left, rotary_changed_right, splash, display ):

    # Macro names or actions
    macro_names = {
        0: "Play / Pause",
        1: "Play/Pause",
        2: "Open Chrome",
        3: "Volume Up",
        4: "Grab",
        # Add more macro names and their corresponding keys as needed
    }
    
    if event and event.pressed and event.key_number == 0:
        cc.send(ConsumerControlCode.VOLUME_DECREMENT)
        time.sleep(0.1)
        
        
    if event and event.pressed and event.key_number == 1:
        cc.send(ConsumerControlCode.PLAY_PAUSE)
        time.sleep(0.3)
        
    if event and event.pressed and event.key_number == 2:
        keyboard.send(Keycode.GUI)
        time.sleep(0.4)
        write_text.write('chrome\n')
        time.sleep(0.2)
        write_text.write('\n')
        time.sleep(1)
        write_text.write('https://www.youtube.com/watch?v=dQw4w9WgXcQ?autoplay=1\n')
    
    if event and event.pressed and event.key_number == 3:
        cc.send(ConsumerControlCode.VOLUME_INCREMENT)
        time.sleep(0.2)
    
    if event and event.pressed and event.key_number == 4:
        print("test")
        keyboard.send(Keycode.N)
        time.sleep(0.3)
    
    #add more events here
        
        
        
    #Rotary encoder turned clockwise
       
    if rotary_changed_left() == True:
        keyboard.send(Keycode.RIGHT_ARROW)
        
        
        
        
    elif rotary_changed_left() == False:
        keyboard.send(Keycode.LEFT_ARROW)
    
    #Rotary encoder turned clockwise
    if rotary_changed_right() == True:
        cc.send(ConsumerControlCode.VOLUME_INCREMENT)
        time.sleep(0.01)
        
        
        
    elif rotary_changed_right() == False:
        cc.send(ConsumerControlCode.VOLUME_DECREMENT)
        time.sleep(0.01)
        
        
    if SW1.value == 0:
        print("Rotary 1 - Button pressed")
        time.sleep(0.2)
        
    if SW2.value == 0:
        print("Rotary 2 - Button pressed")
        time.sleep(0.2)
        

    time.sleep(0.0001)
